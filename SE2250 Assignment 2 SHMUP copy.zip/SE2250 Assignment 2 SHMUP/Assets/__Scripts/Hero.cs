﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// This script controls the hero ship movement using arrow keys and WASD keys.
/// This script also handles helo behaviour with regards to collision events between the hero ship and enemy ships.
/// </summary>

public class Hero : MonoBehaviour
{
    static public Hero S; //Singleton

    [Header("Set in Inspector")]
    // These fields control the movement of the ship
    public float speed = 30;
    public float rollMult = -45;
    public float pitchMult = 30;
    public float gameRestartDelay = 2f;

    void Awake()
    {
        if (S == null)
        {
            S = this; // Set the Singleton
        } else
        {
            Debug.LogError("Hero.Awake() - Attempted to assign second Hero.S!");
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Pull in information from the input class
        float xAxis = Input.GetAxis("Horizontal");
        float yAxis = Input.GetAxis("Vertical");

        // Change transform.position based on the axes
        Vector3 pos = transform.position;
        pos.x += xAxis * speed * Time.deltaTime;
        pos.y += yAxis * speed * Time.deltaTime;
        transform.position = pos;

        // Rotate the ship to make it feel JUICY (more dynamic)
        transform.rotation = Quaternion.Euler(yAxis * pitchMult, xAxis * rollMult, 0);
    }

    // Handler for collision events between the hero ship and enemy ships.
    private void OnTriggerEnter(Collider other)
    {
        Transform rootT = other.gameObject.transform.root;
        GameObject go = rootT.gameObject;
        // When an enemy collides with the player, both, the enemy and the ship are destroyed.
        Destroy(go); // Destroy enemy object in collision
        Destroy(gameObject); // Destroy Hero ship

        // Main.S restart the game after a couple second delay
        Main.S.DelayedRestart(gameRestartDelay);
    }
}
