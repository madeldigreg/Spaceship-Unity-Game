﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// This script programs the enemy ship behaviour such as base movement and speed.
/// When enemy ships are detected outside the bounds check, they are destroyed.
/// </summary>

public class Enemy : MonoBehaviour
{
    [Header("Set in Inspector: Enemy")]
    public float speed = 10f;
    private BoundsCheck bndCheck;

    void Awake()
    {
        bndCheck = GetComponent<BoundsCheck>();
    }

    public Vector3 pos
    {
        get
        {
            return (this.transform.position);
        }
        set
        {
            this.transform.position = value;
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Enemy ships are continuously moving along their trajectoy path.
        Move();

        // If an enemy ship goes off the bottom, left, or right of the screen, the game object is destroyed.
        if (bndCheck != null && (bndCheck.offDown || bndCheck.offLeft || bndCheck.offRight))
        {
            Destroy(gameObject);
        }
    }

    // Base enemy movement is downward/vertically (used for enemy 1).
    public virtual void Move()
    {
        Vector3 tempPos = pos;
        tempPos.y -= speed * Time.deltaTime;
        pos = tempPos;
    }
}
