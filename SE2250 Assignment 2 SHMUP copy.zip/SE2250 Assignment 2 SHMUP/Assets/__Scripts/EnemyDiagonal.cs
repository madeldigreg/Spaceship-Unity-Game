﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// This script enherits from the Enemy Class and overrides the move() function to create diagonal downwards motion (45 degree angle).
/// </summary>

public class EnemyDiagonal : Enemy
{
    private int diagonalDisplace;

    private void Start()
    {
        diagonalDisplace = Random.Range(0, 2) * 2 - 1;
    }

    // Diagonal moving enemy is downward on a 45 degree angle (used for enemy 2).
    public override void Move()
    {
        Vector3 pos = transform.position;
        pos.y -= speed * Time.deltaTime;
        pos.x += Mathf.Sin(Mathf.PI / 4) * speed * diagonalDisplace * Time.deltaTime;
        transform.position = pos;
    }
}
